﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Northwind.Models
{
	public class ICompany
	{
		public String GetName()
		{
			return "";
		}

		public String GetPhone()
		{
			return "";
		}
		/*
		public String GetCompany()
		{
			return "";
		}

		public String GetTitle()
		{
			return "";
		}

		public String GetAddress()
		{
			return "";
		}*/
	}
}