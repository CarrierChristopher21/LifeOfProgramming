﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NWFactoryDemo.Models
{
	public class NWOleDbFactory
	{



		public override INWDataSet CreatDataSet(string aSQL)
		{
			// create the connection object
			OleDbConnection aConnection = new OleDbConnection();

			// set the connection
			aConnection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data; 
			Source=C:\Users\Chris\Desktop\Visual Studio Programming\Visual Studio 2013\Projects\Object_Oriented_Programming\NWFactoryDemo\NWFactoryDemo\Data\Northwind.accdb";

			// open connection
			aConnection.Open();

			// create a command object

		}
	}
}