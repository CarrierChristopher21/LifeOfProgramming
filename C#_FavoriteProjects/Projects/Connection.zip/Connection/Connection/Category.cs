﻿/* Christopher Carrier
 * Lab 1
 * 1/30/14
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Connection
{
    public class Category
    {
        /*      Information about Category Class
            This class receives the data and then assigns the data to a the specific variable
            within the class. Also, this class will test if the data is blank or not available.
            It also sets up the .ToString() format for this file for when its called.
        */

        // Declaration
        private int categoryId = -1;
        private string categoryName = "n/a";
        private string description = "n/a";
        private static int numberOfCategories = 0;

        // Get And Sets
        public int CategoryId
        {
            get
            {
                return categoryId;
            }
        }

        public string CategoryName
        {
            get
            {
                return categoryName;
            }
            set
            {
                if(value.Length > 0)
                {
                    this.categoryName = value;
                }
                else
                {
                    this.categoryName = "n/a";
                }
            }
        }

        public string Description
        {
            get
            {
                return description;
            }
            set
            {
                if(value.Length > 0)
                {
                    this.description = value;
                }
                else
                {
                    this.description = "n/a";
                }
            }
        }

        // Constructors
        public Category()
        {
            Category.numberOfCategories++;
        }

        public Category(int anId, string acategoryName, string adescription)
            : this()
        {
            this.categoryId = anId;                 // Do Not Capatilize the variable for anID
            this.CategoryName = acategoryName;      // Capatilize the rest of the this.variable's
            this.Description = adescription;
        }

        public Category(int anId, string acategoryName)
            : this(anId, acategoryName, "n/a")
        {

        }

        public Category(int anId)
            : this(anId, "n/a", "n/a")
        {

        }

        //  Category Counter
        public static int GetNumberOfCategory()
        {
            return Category.numberOfCategories;
        }

        // Output
        public override string ToString()
        {
            string aString = "";
            aString = aString + "Category ID = " + CategoryId + "\n";
            aString = aString + "Category Name = " + CategoryName + "\n";
            aString = aString + "Description = " + Description + "\n";
            aString = aString + "Number Of Categories = " + numberOfCategories + "\n";

            return aString;
        }
    }
}
