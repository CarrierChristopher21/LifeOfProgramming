	function RollDice()
	{	
		
		do{	
			var die1;
			var die2;
			var user;
			var comp;
			var userscore = 0;
			var compscore = 0;
			var turn;
			var num = 0;

			alert("Human turn");
			if("imgDisplay1")
			{
				die1 = Math.floor(1 + Math.random() * 6);
				var roll1 = document.getElementById("die1").type;	
				//die1 = Math.floor(1 + (Math.random() * 6));// Loop this through to keep getting a different dice 
				//number
			}
			else if("imgDisplay2")
			{	
				var roll2 = document.getElementById("die2").type;
				die2 = Math.floor(1 + Math.random() * 6);
			}
			
			
			var preLoadedDiceImages = new Array(5);
			//download the first image
			preLoadedDiceImages[0] = new Image(100, 100);
			preLoadedDiceImages[0].src = "die1.png";
						
			preLoadedDiceImages[1] = new Image(100, 100);
			preLoadedDiceImages[1].src = "die2.png";
						
			preLoadedDiceImages[2] = new Image(100, 100);
			preLoadedDiceImages[2].src = "die3.png";
						
			preLoadedDiceImages[3] = new Image(100, 100);
			preLoadedDiceImages[3].src = "die4.png";
				
			preLoadedDiceImages[4] = new Image(100, 100);
			preLoadedDiceImages[4].src = "die5.png";
						
			preLoadedDiceImages[5] = new Image(100, 100);
			preLoadedDiceImages[5].src = "die6.png";
					
				
		
		
		if(turn%2==0) //if turn is even its users turn
		{
			continue;
			var roll = document.forms.diceRollingForm.roll.submit;
			var hold = document.forms.diceRollingForm.hold.submit;
			
			//user turn
			if(die1 = preLoadedDiceImages[0] || die2 = preLoadedDiceImages[0])
			{
				break;
			}
			else if(die1 = preLoadedDiceImages[1] || die2 = preLoadedDiceImages[1])
			{
				num = 2;
				userscore = userscore + num;
			}
			else if(die1 = preLoadedDiceImages[2] || die2 = preLoadedDiceImages[2])
			{
				num = 3;
				userscore = userscore + num;
			}
			else if(die1 = preLoadedDiceImages[3] || die2 = preLoadedDiceImages[3])
			{
				num = 4;
				userscore = score + num;
			}
			else if(die1 = preLoadedDiceImages[4] || die2 = preLoadedDiceImages[4])
			{
				num = 5;
				userscore = score + num;
			}
			else if(die1 = preLoadedDiceImages[5] || die2 = preLoadedDiceImages[5])
			{
				num = 6;
				userscore = userscore + num;
			}
			if(die1)
			{
				//swap the image to the requested number
				document.forms.diceRollingForm.imgDisplay1.src = preLoadedDiceImages[imageNumber].src;
			}
			else if(die2)
			{
				//swap the image to the requested number
				document.forms.diceRollingForm.imgDisplay2.src = preLoadedDiceImages[imageNumber].src;
			}
			turn++;
		}
		else //otherwise its odd which is computer turn
		{
			continue;
			var roll = document.forms.diceRollingForm.roll.submit;
			var hold = document.forms.diceRollingForm.hold.submit;
			
			//computer turn
			if(die1 = preLoadedDiceImages[0] || die2 = preLoadedDiceImages[0])
			{
				break;
			}
			else if(die1 = preLoadedDiceImages[1] || die2 = preLoadedDiceImages[1])
			{
				num = 2;
				comp = compscore + num;
			}
			else if(die1 = preLoadedDiceImages[2] || die2 = preLoadedDiceImages[2])
			{
				num = 3;
				comp = compscore + num;
			}
			else if(die1 = preLoadedDiceImages[3] || die2 = preLoadedDiceImages[3])
			{
				num = 4;
				comp = compscore + num;
			}
			else if(die1 = preLoadedDiceImages[4] || die2 = preLoadedDiceImages[4])
			{
				num = 5;
				comp = compscore + num;
			}
			else if(die1 = preLoadedDiceImages[5] || die2 = preLoadedDiceImages[5])
			{
				num = 6;
				comp = compscore + num;
			}
			turn++;
		}
						
		if(die1)
		{
			//swap the image to the requested number
			document.forms.diceRollingForm.imgDisplay1.src = preLoadedDiceImages[imageNumber].src;
		}
		else if(die2)
		{
			//swap the image to the requested number
				document.forms.diceRollingForm.imgDisplay2.src = preLoadedDiceImages[imageNumber].src;
		}
		document.write("<p>Your score is: </p>" + userscore); 
		document.write("<p>Computer score is: </p>" + compscore);
		document.write("<p>Turn total is: </p>" + turn);
		}while(userscore = 100 || compscore = 100)
	}
			
			
			
		
			