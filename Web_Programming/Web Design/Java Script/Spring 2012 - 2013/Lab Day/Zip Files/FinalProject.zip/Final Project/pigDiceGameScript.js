			
			var die1;
			var die2;
			var roll = document.forms.diceRollingForm.roll.submit;
			var hold = document.forms.diceRollingForm.hold.submit;
			var score;
			
			var preLoadedDiceImages = new Array(5);
			function dicepreload()
			{
				//download the first image
				preLoadedDiceImages[0] = new Image(100, 100);
				preLoadedDiceImages[0].src = "die1.png";
					
				preLoadedDiceImages[1] = new Image(100, 100);
				preLoadedDiceImages[1].src = "die2.png";
					
				preLoadedDiceImages[2] = new Image(100, 100);
				preLoadedDiceImages[2].src = "die3.png";
					
				preLoadedDiceImages[3] = new Image(100, 100);
				preLoadedDiceImages[3].src = "die4.png";
				
				preLoadedDiceImages[4] = new Image(100, 100);
				preLoadedDiceImages[4].src = "die5.png";
					
				preLoadedDiceImages[5] = new Image(100, 100);
				preLoadedDiceImages[5].src = "die6.png";
					
				//alert("Function has completed");
			}
			function determine()
			{
				if(die1 = preLoadedDiceImages[0] || die2 = preLoadedDiceImages[0])
				{
					
				}
				else if(die1 = preLoadedDiceImages[1] || die2 = preLoadedDiceImages[1])
				{
					score = 2;
				}
				else if(die1 = preLoadedDiceImages[2] || die2 = preLoadedDiceImages[2])
				{
					score = 3;
				}
				else if(die1 = preLoadedDiceImages[3] || die2 = preLoadedDiceImages[3])
				{
					score = 4;
				}
				else if(die1 = preLoadedDiceImages[4] || die2 = preLoadedDiceImages[4])
				{
					score = 5;
				}
				else if(die1 = preLoadedDiceImages[5] || die2 = preLoadedDiceImages[5])
				{
					score = 6;
				}

			
			}
			function displayResult()
			{
				
				if("imgDisplay1")
				{
					die1 = Math.floor((Math.random() * 5) + 1);// Loop this through to keep getting a different dice 
					var roll1 = document.getElementById("die1").type;			//number
				}
				else if("imgDisplay2")
				{
					die2 = Math.floor((Math.random() * 5) + 1);
					var roll2 = document.getElementById("die2").type;
					
				}
			}
			function rollclick()
			{
				
				
			}
			function holdclick()
			{
				
			}
			function roll1(imageNumber)
			{
				//swap the image to the requested number
				document.forms.diceRollingForm.imgDisplay1.src = preLoadedDiceImages[imageNumber].src;
			}
			function roll2(imageNumber)
			{
				//swap the image to the requested number
				document.forms.diceRollingForm.imgDisplay2.src = preLoadedDiceImages[imageNumber].src;
			}
			
			
			
			
			