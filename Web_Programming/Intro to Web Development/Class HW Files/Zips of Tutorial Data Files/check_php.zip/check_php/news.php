<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Check Magazine</title>
<link href="styles/check_cs5.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<link href="styles/check_menu.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="container">
  <h1>Check Magazine: Fashion and Lifestyle</h1>
  <div id="banner"> <img src="images/banner.gif" width="968" height="100" alt="Check Magazine" />
    <ul id="check_menu" class="MenuBarHorizontal">
      <li><a href="index.php">Features</a></li>
      <li><a href="#">Fashion</a></li>
      <li><a href="#">Lifestyle</a></li>
      <li><a href="#">Calendar</a></li>
      <li><a href="news.php">News</a></li>
    </ul>
  </div>
<img src="images/news2.gif" width="979" height="749" alt="" /> </div>
<script type="text/javascript">
var MenuBar1 = new Spry.Widget.MenuBar("check_menu", {imgDown:"SpryAssets/SpryMenuBarDownHover.gif", imgRight:"SpryAssets/SpryMenuBarRightHover.gif"});
</script>
</body>
</html>