﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Northwind4.Models;

namespace Northwind4.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        public ActionResult Index()
        {

            /*Category aCategory1 = new Category();
            Category aCategory2 = new Category();
            Category aCategory3 = new Category();

            aCategory1.CategoryId = 1;
            aCategory1.CategoryName = "Beverages";
            aCategory1.Description = "Soft drinks, coffees, teas, beers, and ales";

            aCategory2.CategoryId = 2;
            aCategory2.CategoryName = "Condiments";
            aCategory2.Description = "Sweet and savory sauces, relishes, spreads, and seasonings";

            aCategory3.CategoryId = 3;
            aCategory3.CategoryName = "Confections";
            aCategory3.Description = "Desserts, candies, and sweet breads";
            
                    
            aListOfCategories.Add(aCategory1);
            aListOfCategories.Add(aCategory2);
            aListOfCategories.Add(aCategory3);

             */

            List<Category> aListOfCategories = new List<Category>();
            DbConnection aConnection = DbConnection.Instance;

            ViewBag.ListOfCategories = aConnection.GetCategories();

            return View();
        }
	}
}