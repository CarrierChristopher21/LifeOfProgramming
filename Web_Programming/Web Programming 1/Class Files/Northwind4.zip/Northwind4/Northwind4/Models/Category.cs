﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Threading.Tasks;

namespace Northwind4.Models
{

    public class Category
    {
        private int categoryId = -1;
        private string categoryName = "n/a";
        private string description = "n/a";


        public int CategoryId
        {
            get
            {
                return this.categoryId;
            }
            set
            {
                this.categoryId = value;

            }


        }

        public string CategoryName
        {
            get
            {
                return this.categoryName;
            }

            set
            {
                this.categoryName = value;
            }
        }

        public string Description
        {
            get
            {
                return this.description;
            }

            set
            {
                this.description = value;
            }
        }



        

        // ToString  

        public override string ToString()
        {
            string aString = "";
            aString = aString + "SupplierId = " + CategoryId + "\n";
            aString = aString + "Category Name = " + CategoryName + "\n";
            aString = aString + "Description = " + Description + "\n";
           
            return aString;
        }

        public string Display()
        {
            string aString = "";
            aString = aString + "Category Id = " + CategoryId + "<br />";
            aString = aString + "Category Name = " + CategoryName + "<br />";
            aString = aString + "Description = " + Description + "<br /><br />";
           
            return aString;
        }
    }
}